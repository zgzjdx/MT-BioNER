"""
author:yqtong@stu.xmu.edu.cn
date:2020-12-15
"""
import numpy as np
from sklearn.manifold import TSNE
import networkx as nx
import matplotlib.pyplot as plt
from fa2 import ForceAtlas2
layer_list = ['encoder.layer.0.layer_output.npy',
              'encoder.layer.1.layer_output.npy',
              'encoder.layer.2.layer_output.npy',
              'encoder.layer.3.layer_output.npy',
              'encoder.layer.4.layer_output.npy',
              'encoder.layer.5.layer_output.npy',
              'encoder.layer.6.layer_output.npy',
              'encoder.layer.7.layer_output.npy',
              'encoder.layer.8.layer_output.npy',
              'encoder.layer.9.layer_output.npy',
              'encoder.layer.10.layer_output.npy',
              'encoder.layer.11.layer_output.npy',]


def read_feature(file_path):
    """
    :param file_path:
    :return:
    """
    for layer in layer_list:
        if 'layer.0' in layer:
            feature = np.load('{}/{}'.format(file_path, layer))
        else:
            feature += np.load('{}/{}'.format(file_path, layer))
    return feature / len(layer_list)


def normalize(result):
    """
    :param result:
    :return:
    """
    x_list = []
    y_list = []
    final_result = []
    for idx in range(len(result)):
        x_list.append(result[idx][0])
        y_list.append(result[idx][-1])
    x_max = max(x_list)
    x_min = min(x_list)
    for idx in range(len(x_list)):
        x_list[idx] = x_list[idx] - x_min / x_max - x_min
    y_max = max(y_list)
    y_min = min(y_list)
    for idx in range(len(y_list)):
        y_list[idx] = y_list[idx] - y_min / y_max - y_min
    for idx in range(len(result)):
        final_result.append([x_list[idx], y_list[idx]])
    return final_result


if __name__ == '__main__':
    # feature1 = read_feature('task_embedding/BC2GM-IOB').reshape(1, -1)
    # feature2 = read_feature('task_embedding/BC2GM-bCLS').reshape(1, -1)
    # feature3 = read_feature('task_embedding/BC2GM-mCLS').reshape(1, -1)
    # feature4 = read_feature('task_embedding/BC2GM-mtCLS').reshape(1, -1)
    # feature5 = read_feature('task_embedding/BC5CDR-chem-IOB').reshape(1, -1)
    # feature6 = read_feature('task_embedding/BC5CDR-chem-bCLS').reshape(1, -1)
    # feature7 = read_feature('task_embedding/BC5CDR-chem-mCLS').reshape(1, -1)
    # feature8 = read_feature('task_embedding/BC5CDR-chem-mtCLS').reshape(1, -1)
    # feature9 = read_feature('task_embedding/NCBI-disease-IOB').reshape(1, -1)
    # feature10 = read_feature('task_embedding/NCBI-disease-bCLS').reshape(1, -1)
    # feature11 = read_feature('task_embedding/NCBI-disease-mCLS').reshape(1, -1)
    # feature12 = read_feature('task_embedding/NCBI-disease-mtCLS').reshape(1, -1)
    # final_feature = np.concatenate((feature1, feature2, feature3, feature4, feature5,
    #                                 feature6, feature7, feature8,feature9, feature10,
    #                                 feature11, feature12), axis=0)
    # print(final_feature.shape)
    # tsne = TSNE(n_components=2, learning_rate=10, early_exaggeration=3, perplexity=3, random_state=2021, n_iter=1000)
    # tsne.fit_transform(final_feature)
    # result = tsne.embedding_
    # print(result)
    # 我要画的是12个点, 代表12个task的embedding, 3个数据集之间的点用线与线相连
    # 所以result应该是包含12个列表的列表, 每个列表都是二维, 代表一个任务的embedding, 并做normalization
    forceatlas2 = ForceAtlas2(
        # Behavior alternatives
        outboundAttractionDistribution=True,  # Dissuade hubs
        linLogMode=False,  # NOT IMPLEMENTED
        adjustSizes=False,  # Prevent overlap (NOT IMPLEMENTED)
        edgeWeightInfluence=1.0,

        # Performance
        jitterTolerance=1.0,  # Tolerance
        barnesHutOptimize=True,
        barnesHutTheta=1.2,
        multiThreaded=False,  # NOT IMPLEMENTED

        # Tuning
        scalingRatio=2.0,
        strongGravityMode=False,
        gravity=1.0,

        # Log
        verbose=True)
    result = [[7.463206, - 9.71517], [-4.012402, 14.539554], [-4.4887576, 11.790675], [9.3363495, 4.0561924],
              [9.120407, -10.364909], [-5.9522643, 15.999742], [-5.205508, 8.223093], [8.103228, 5.3456893],
              [8.937993, -8.656041], [-5.3635635, 13.925307], [-3.8656247, 8.905858], [9.796167, 5.789006]]
    G = nx.Graph(result)
    positions = forceatlas2.forceatlas2(G, pos=None, iterations=2000)
    nx.draw_networkx_nodes(G, positions, node_size=20, with_labels=False, node_color="blue", alpha=0.4)
    nx.draw_networkx_edges(G, positions, edge_color="green", alpha=0.05)
    plt.axis('off')
    plt.show()
    # text_list = ['BC2GM-IOB', 'BC2GM-bCLS', 'BC2GM-mCLS', 'BC2GM-mtCLS',
    #              'BC5CDR-IOB', 'BC5CDR-bCLS', 'BC5CDR-mCLS', 'BC5CDR-mtCLS',
    #              'NCBI-IOB', 'NCBI-bCLS', 'NCBI-mCLS', 'NCBI-mtCLS',]
    # plt.figure(figsize=(4,4))
    # for i in range(len(result)):
    #     plt.scatter(result[i][0], result[i][1])
    # for i in range(len(result)):
    #     plt.text(result[i][0] * 1.02, result[i][1] * 1.02, text_list[i])
    # plt.axis('off')
    # plt.show()

