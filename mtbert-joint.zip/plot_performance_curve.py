"""
author:yqtong@stu.xmu.edu.cn
date:2020-12-06
"""
# 58 for NCBI-disease
# 29 for BC2GM
# 36 for BC5CDR
import matplotlib.pyplot as plt


def get_f1(file_path):
    with open(file_path, 'r', encoding='utf-8') as fa:
        ner_f1_list = []
        mt_f1_list = []
        bcls_f1_list = []
        mcls_f1_list = []
        line_list = fa.readlines()
        ner_flag = True
        bcls_flag = True
        for line in line_list:
            line = line.strip()
            if 'Task' in line and 'Test' in line:
                temp_list = line.split('  ')
                score = temp_list[-1]
                score = float(score)
                if 'SeqEval' in line and ner_flag:
                    ner_f1_list.append(score)
                    ner_flag = False
                elif 'SeqEval' in line and not ner_flag:
                    mt_f1_list.append(score)
                    ner_flag = True
                elif 'MicroF1' in line and bcls_flag:
                    bcls_f1_list.append(score)
                    bcls_flag = False
                elif 'MicroF1' in line and not bcls_flag:
                    mcls_f1_list.append(score)
                    bcls_flag = True
                else:
                    continue
            else:
                continue
        assert len(ner_f1_list) == len(mt_f1_list) == len(bcls_f1_list) == len(mcls_f1_list)
    return ner_f1_list, mt_f1_list, bcls_f1_list, mcls_f1_list


if __name__ == '__main__':
    NCBI_ner_f1, NCBI_mt_f1, NCBI_bcls_f1, NCBI_mcls_f1 = get_f1('NCBI_multi_train.out')
    BC5CDR_ner_f1, BC5CDR_mt_f1, BC5CDR_bcls_f1, BC5CDR_mcls_f1 = get_f1('BC5CDR_multi_train.out')
    BC2GM_ner_f1, BC2GM_mt_f1, BC2GM_bcls_f1, BC2GM_mcls_f1 = get_f1('BC2GM_multi_train.out')
    BC2GM_epochs = [x for x in range(3, 41)]
    x1 = BC2GM_epochs
    BC5CDR_epochs = [x for x in range(3, 41)]
    x2 = BC5CDR_epochs
    NCBI_epochs = [x for x in range(3, 41)]
    x3 = NCBI_epochs
    y1, y2, y3, y4 = [], [], [], []
    y5, y6, y7, y8 = [], [], [], []
    y9, y10, y11, y12 = [], [], [], []
    for idx in BC2GM_epochs:
        y1.append(BC2GM_ner_f1[idx-1])
        y2.append(BC2GM_mt_f1[idx-1])
        y3.append(BC2GM_bcls_f1[idx-1])
        y4.append(BC2GM_mcls_f1[idx-1])
    for idx in BC5CDR_epochs:
        y5.append(BC5CDR_ner_f1[idx-1])
        y6.append(BC5CDR_mt_f1[idx-1])
        y7.append(BC5CDR_bcls_f1[idx-1])
        y8.append(BC5CDR_mcls_f1[idx-1])
    for idx in NCBI_epochs:
        y9.append(NCBI_ner_f1[idx-1])
        y10.append(NCBI_mt_f1[idx-1])
        y11.append(NCBI_bcls_f1[idx-1])
        y12.append(NCBI_mcls_f1[idx-1])
    font1 = {'family': 'Times New Roman',
             'weight': 'normal',
             'size': 16,
             }
    plt.figure(figsize=(4, 7))
    plt.figure(1)
    ax1 = plt.subplot(311)
    plt.plot(x1, y1, color='r', linewidth=2)
    plt.plot(x1, y2, color='b', linewidth=2)
    plt.plot(x1, y3, color='g', linewidth=2)
    plt.plot(x1, y4, color='coral', linewidth=2)
    plt.xticks([0, 10, 20, 30, 40])
    # plt.xticks([0, 5, 10, 15, 20])
    plt.yticks([0.7, 0.8, 0.9, 1.0])
    plt.xlabel('(a) BC2GM')
    plt.ylabel('F1-Score')
    ax1.spines['right'].set_visible(False)
    ax1.spines['top'].set_visible(False)

    ax2 = plt.subplot(312)
    plt.plot(x2, y5, color='r', linewidth=2)
    plt.plot(x2, y6, color='b', linewidth=2)
    plt.plot(x2, y7, color='g', linewidth=2)
    plt.plot(x2, y8, color='coral', linewidth=2)
    plt.xticks([0, 10, 20, 30, 40])
    plt.yticks([0.9, 0.95, 1.0])
    plt.xlabel('(b) BC5CDR-chem')
    plt.ylabel('F1-Score')
    ax2.spines['right'].set_visible(False)
    ax2.spines['top'].set_visible(False)


    ax3 = plt.subplot(313)
    plt.plot(x3, y9, label='NER', color='r', linewidth=2)
    plt.plot(x3, y10, label='mtCLS', color='b', linewidth=2)
    plt.plot(x3, y11, label='bCLS', color='g', linewidth=2)
    plt.plot(x3, y12, label='mCLS', color='coral', linewidth=2)
    plt.xticks([0, 10, 20, 30, 40])
    # plt.xticks([0, 10, 20, 30, 30])

    plt.yticks([0.2, 0.4, 0.6, 0.8, 1.0])
    plt.xlabel('(c) NCBI-disease')
    plt.ylabel('F1-Score')
    plt.legend()
    ax3.spines['right'].set_visible(False)
    ax3.spines['top'].set_visible(False)

    plt.tight_layout()
    plt.show()

