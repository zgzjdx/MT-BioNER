"""
author:yqtong@stu.xmu.edu.cn
date:2020-11-12
"""
import torch
import torch.nn as nn
from torch.autograd import Variable


def sequence_mask(lengths, max_len=None):
    """
    Create a boolean mask from sequence lengths.
    :param lengths:
    :param max_len:
    """
    batch_size = lengths.numel()
    max_len = max_len or lengths.max()
    return (torch.arange(0, max_len).type_as(lengths).repeat(batch_size, 1).lt(lengths.unsqueeze(1)))


class DynamicCache(nn.Module):
    # 初始化
    def __init__(self, cache_dim, cache_size, rnn_type, input_size, num_layers, dropout, opt):
        super(DynamicCache, self).__init__()
        self.cache_dim = int(cache_dim)
        self.cache_size = int(cache_size)
        # 将encoder输入lstm中, 是否需要用, 待定
        # todo 理论上bilstm的效果要好于lstm
        # todo label embedding
        self.cache_embedding_rnn = getattr(nn, rnn_type)(
            input_size=input_size, # 输入的隐层维度
            hidden_size=cache_dim, # LSTM的隐层维度 512
            num_layers=num_layers, # LSTM层数
            dropout=dropout
        )
        # linear和sigmoid函数 用于给当前的状态进行打分
        self.linear = nn.Linear(cache_dim, 1)
        self.sigmoid = nn.Sigmoid()
        # 定义一个网络初始的hidden=None
        self.hidden = None
        # key-value cache key存储document状态 value存储encoder的原始状态 score存储sigmoid函数的概率打分
        self.key = []
        self.value = []
        self.score = []
        # id
        self.word_cache = []
        # global attention用, 需要定义额外的document_memory_lengths
        self.document_memory_lengths = None
        self.oldest_index = 0
        self.opt = opt
        # 过滤CLS, SEP, PAD
        self.stop_words_list = [101, 102, 0]

    def forward(self, input_ids, sequence_output):
        """
        :param input_ids:
        :param sequence_output:
        :return:
        """
        if not self.key:
            # 此时cache为空, 写入, rnn的输出做key, bert的输出做value, sigmoid的输出做score, input_id做id
            rnn_otuput, _ = self.cache_embedding_rnn(sequence_output, self.hidden)  # batch_size * sequence_len * hidden_size
            cache_logits = self.sigmoid(self.linear(rnn_otuput))  # batch_size * sequence_len
            assert len(self.key) == len(self.value) == len(self.word_cache) == len(self.score)
            batch_size, seq_len, _ = rnn_otuput.size()
            for idx in range(batch_size):
                for idy in range(seq_len):
                    # cache还未写满
                    if input_ids[idx][idy] in self.stop_words_list:
                        continue

                    if len(self.key) < self.cache_size:
                        self.key.append(rnn_otuput[idx][idy])  # hidden_size 512
                        self.value.append(sequence_output[idx][idy])  # hidden_Size 768
                        self.word_cache.append(input_ids[idx][idy])
                        self.score.append(cache_logits[idx][idy])  # sigmoid = sequence_len * 1
                    # cache写满
                    else:
                        if self.opt['cache_update_strategy'] == 'normal':
                            # rule1 先进先出
                            if self.oldest_index >= self.cache_size:
                                self.oldest_index = 0
                            self.key[self.oldest_index] = rnn_otuput[idx][idy]
                            self.value[self.oldest_index] = sequence_output[idx][idy]
                            self.word_cache[self.oldest_index] = input_ids[idx][idy]
                            self.score[self.oldest_index] = cache_logits[idx][idy]
                            self.oldest_index += 1
                        elif self.opt['cache_update_strategy'] == 'score':
                            # rule2 根据打分函数
                            min_score = min(self.score)
                            min_score_index = self.score.index(min_score)
                            current_score = cache_logits[idx][idy]
                            if current_score >= min_score:
                                # 相关性高, 保留
                                if input_ids[idx][idy] in self.word_cache:
                                    index = self.word_cache.index(input_ids[idx][idy])
                                    self.key[index] = rnn_otuput[idx][idy]
                                    self.value[index] = sequence_output[idx][idy]
                                    self.word_cache[index] = input_ids[idx][idy]
                                    self.score[index] = current_score
                                else:
                                    self.key[min_score_index] = rnn_otuput[idx][idy]
                                    self.value[min_score_index] = sequence_output[idx][idy]
                                    self.word_cache[min_score_index] = input_ids[idx][idy]
                                    self.score[min_score_index] = current_score
                            else:
                                # 相关性低, 不保留
                                continue
                        else:
                            raise ValueError
            # print('debug use')

        else:
            # 若cache不为空
            assert len(self.key) == len(self.value) == len(self.word_cache) == len(self.score)
            rnn_otuput, _ = self.cache_embedding_rnn(sequence_output,
                                                     self.hidden)  # batch_size * sequence_len * hidden_size
            cache_logits = self.sigmoid(self.linear(rnn_otuput))
            batch_size, seq_len, _ = rnn_otuput.size()
            # cache不为空, 但未写满
            if len(self.key) < self.cache_size:
                diff = self.cache_size - len(self.key)
                count = 0
                for idx in range(len(batch_size)):
                    for idy in range(len(seq_len)):
                        # 过滤停用词
                        if input_ids[idx][idy] in self.stop_words_list:
                            continue
                        # 先写满
                        if count < diff:
                            self.key.append(rnn_otuput[idx][idy])
                            self.value.append(sequence_output[idx][idy])
                            self.word_cache.append(input_ids[idx][idy])
                            self.score.append(cache_logits[idx][idy])  # sigmoid = sequence_len * 1
                            count += 1
                        # 写满后开始更新
                        else:
                            if self.opt['cache_update_strategy'] == 'normal':
                                # rule1 先进先出
                                if self.oldest_index >= self.cache_size:
                                    self.oldest_index = 0
                                self.key[self.oldest_index] = rnn_otuput[idx][idy]
                                self.value[self.oldest_index] = sequence_output[idx][idy]
                                self.word_cache[self.oldest_index] = input_ids[idx][idy]
                                self.score[self.oldest_index] = cache_logits[idx][idy]
                                self.oldest_index += 1
                            elif self.opt['cache_update_strategy'] == 'score':
                                # rule2 根据打分函数更新
                                min_score = min(self.score)
                                min_score_index = self.score.index(min_score)
                                current_score = cache_logits[idx][idy]
                                if current_score > min_score:
                                    # 相关性高, 保留
                                    if input_ids[idx][idy] in self.word_cache:
                                        index = self.word_cache.index(input_ids[idx][idy])
                                        self.key[index] = rnn_otuput[idx][idy]
                                        self.value[index] = sequence_output[idx][idy]
                                        self.word_cache[index] = input_ids[idx][idy]
                                        self.score[index] = current_score
                                    else:
                                        self.key[min_score_index] = rnn_otuput[idx][idy]
                                        self.value[min_score_index] = sequence_output[idx][idy]
                                        self.word_cache[min_score_index] = input_ids[idx][idy]
                                        self.score[min_score_index] = current_score
                                else:
                                    # 相关性低, 不保留
                                    continue
                            else:
                                raise ValueError
            # cache不为空且写满
            else:
                for idx in range(batch_size):
                    for idy in range(seq_len):
                        # 过滤停用词
                        if input_ids[idx][idy] in self.stop_words_list:
                            continue
                        if self.opt['cache_update_strategy'] == 'normal':
                            # rule1 先进先出
                            if self.oldest_index >= self.cache_size:
                                self.oldest_index = 0
                            self.key[self.oldest_index] = rnn_otuput[idx][idy]
                            self.value[self.oldest_index] = sequence_output[idx][idy]
                            self.word_cache[self.oldest_index] = input_ids[idx][idy]
                            self.score[self.oldest_index] = cache_logits[idx][idy]
                        elif self.opt['cache_update_strategy'] == 'score':
                            # rule2 根据打分函数更新
                            min_score = min(self.score)
                            min_score_index = self.score.index(min_score)
                            current_score = cache_logits[idx][idy]
                            if current_score > min_score:
                                # 相关性高, 保留
                                if input_ids[idx][idy] in self.word_cache:
                                    index = self.word_cache.index(input_ids[idx][idy])
                                    self.key[index] = rnn_otuput[idx][idy]
                                    self.value[index] = sequence_output[idx][idy]
                                    self.word_cache[index] = input_ids[idx][idy]
                                    self.score[index] = current_score
                                else:
                                    self.key[min_score_index] = rnn_otuput[idx][idy]
                                    self.value[min_score_index] = sequence_output[idx][idy]
                                    self.word_cache[min_score_index] = input_ids[idx][idy]
                                    self.score[min_score_index] = current_score
                            else:
                                # 相关性低, 不保留
                                continue
                        else:
                            raise ValueError
        # batch_size * sequence_len
        return cache_logits.squeeze()


if __name__ == '__main__':
    a = torch.randn(1, 2, 3, 4, 5)
    print(a.shape)
    # Returns the total number of elements in the input tensor.
    b = a.numel()
    print(b)
    print(sequence_mask(a))