"""
author:yqtong@stu.xmu.edu.cn
date:2020-12-14
"""
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd

f, (ax1,ax2, ax3) = plt.subplots(figsize=(8,8),nrows=3)
cmap = sns.cubehelix_palette(start=1.5, rot=3, gamma=0.8, as_cmap=True)

list1 = [[0, 72.42, 67.03, 72.22], [72.42, 0, 68.97, 71.11], [67.03, 68.97, 0, 64.10], [72.22, 71.11, 64.10, 0]]
data1 = pd.DataFrame(list1, columns=['NER', 'bCLS', 'mCLS', 'mtCLS'],
                     index=['NER', 'bCLS', 'mCLS', 'mtCLS'])
list2 = [[0.00, 0.41, 0.32, 0.64], [0.75, 0, 0.71, 0.73], [0.59, 0.48, 0, 0.86], [0.30, -0.33, -0.10, 0]]
data2 = pd.DataFrame(list2, columns=['NER', 'bCLS', 'mCLS', 'mtCLS'],
                     index=['NER', 'bCLS', 'mCLS', 'mtCLS'])
list3 = [[0, 0.17, 0.32, -0.14], [0.11, 0, 0.11, 0.86], [0.42, -0.21, 0, +1.06], [1.00, 1.30, 0.76, 0]]
data3 = pd.DataFrame(list3, columns=['NER', 'bCLS', 'mCLS', 'mtCLS'],
                     index=['NER', 'bCLS', 'mCLS', 'mtCLS'])
sns.heatmap(data1, center=0, linewidths=0.05, annot=True, mask=data1 == '0', ax=ax1, cmap='YlGnBu')
ax1.set_xlabel('(a) BC2GM')
ax1.set_facecolor("gainsboro")
sns.heatmap(data2, linewidths=0.05, annot=True, ax=ax2, mask=data2 ==0, cmap='YlGnBu')
ax2.set_xlabel('(b) BC5CDR-chem')
ax2.set_facecolor("gainsboro")
sns.heatmap(data3, linewidths=0.05, annot=True, ax=ax3, mask=data3 == 0, cmap='YlGnBu')
ax3.set_xlabel('(c) NCBI-disease')
ax3.set_facecolor("gainsboro")
plt.show()