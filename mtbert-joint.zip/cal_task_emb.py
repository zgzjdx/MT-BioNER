"""
author:yqtong@stu.xmu.edu.cn
date:2020-12-09
"""
import numpy as np
import os
from sklearn.metrics import pairwise_distances
import math
os.environ["KMP_DUPLICATE_LIB_OK"]  =  "TRUE"


def cosine_distance(a, b):
    if a.shape != b.shape:
        raise RuntimeError("array {} shape not match {}".format(a.shape, b.shape))
    if a.ndim==1:
        a_norm = np.linalg.norm(a)
        b_norm = np.linalg.norm(b)
    elif a.ndim==2:
        a_norm = np.linalg.norm(a, axis=1, keepdims=True)
        b_norm = np.linalg.norm(b, axis=1, keepdims=True)
    else:
        raise RuntimeError("array dimensions {} not right".format(a.ndim))
    similiarity = np.dot(a, b.T)/(a_norm * b_norm)
    dist = 1. - similiarity
    return dist


layer_list = ['encoder.layer.0.layer_output.npy',
              'encoder.layer.1.layer_output.npy',
              'encoder.layer.2.layer_output.npy',
              'encoder.layer.3.layer_output.npy',
              'encoder.layer.4.layer_output.npy',
              'encoder.layer.5.layer_output.npy',
              'encoder.layer.6.layer_output.npy',
              'encoder.layer.7.layer_output.npy',
              'encoder.layer.8.layer_output.npy',
              'encoder.layer.9.layer_output.npy',
              'encoder.layer.10.layer_output.npy',
              'encoder.layer.11.layer_output.npy',
              'encoder.layer.0.multihead_output.npy',
              'encoder.layer.1.multihead_output.npy',
              'encoder.layer.2.multihead_output.npy',
              'encoder.layer.3.multihead_output.npy',
              'encoder.layer.4.multihead_output.npy',
              'encoder.layer.5.multihead_output.npy',
              'encoder.layer.6.multihead_output.npy',
              'encoder.layer.7.multihead_output.npy',
              'encoder.layer.8.multihead_output.npy',
              'encoder.layer.9.multihead_output.npy',
              'encoder.layer.10.multihead_output.npy',
              'encoder.layer.11.multihead_output.npy',
              'encoder.layer.0.attention.output.LayerNorm.weight.npy',
              'encoder.layer.1.attention.output.LayerNorm.weight.npy',
              'encoder.layer.2.attention.output.LayerNorm.weight.npy',
              'encoder.layer.3.attention.output.LayerNorm.weight.npy',
              'encoder.layer.4.attention.output.LayerNorm.weight.npy',
              'encoder.layer.5.attention.output.LayerNorm.weight.npy',
              'encoder.layer.6.attention.output.LayerNorm.weight.npy',
              'encoder.layer.7.attention.output.LayerNorm.weight.npy',
              'encoder.layer.8.attention.output.LayerNorm.weight.npy',
              'encoder.layer.9.attention.output.LayerNorm.weight.npy',
              'encoder.layer.10.attention.output.LayerNorm.weight.npy',
              'encoder.layer.11.attention.output.LayerNorm.weight.npy',
              'encoder.layer.0.attention.output.dense.bias.npy',
              'encoder.layer.1.attention.output.dense.bias.npy',
              'encoder.layer.2.attention.output.dense.bias.npy',
              'encoder.layer.3.attention.output.dense.bias.npy',
              'encoder.layer.4.attention.output.dense.bias.npy',
              'encoder.layer.5.attention.output.dense.bias.npy',
              'encoder.layer.6.attention.output.dense.bias.npy',
              'encoder.layer.7.attention.output.dense.bias.npy',
              'encoder.layer.8.attention.output.dense.bias.npy',
              'encoder.layer.9.attention.output.dense.bias.npy',
              'encoder.layer.10.attention.output.dense.bias.npy',
              'encoder.layer.11.attention.output.dense.bias.npy',
              'embeddings.LayerNorm.weight.npy',
              'embeddings.LayerNorm.bias.npy']


def read_npy(file_path):
    """
    :param file_path:
    :return:
    """
    file_path_list = os.listdir(file_path)
    result = []
    for file in file_path_list:
        if file in layer_list:
            result.append(np.load(os.path.join(file_path, file)).reshape(-1))
        else:
            continue
    return result


def compute_task_pair_similarity(result_a, result_b):
    """
    :param result_a:
    :param result_b:
    :return:
    """
    assert len(result_a) == len(result_b), 'The length of two list should be same'
    result = 0
    for a, b in zip(result_a, result_b):
        result += cosine_distance(a, b)
    return result / len(result_a)


def compute_layer_wise_similarity(file_path_a, file_path_b):
    """
    :param file_path_a:
    :param file_path_b:
    :return:
    """
    dir_list_a = os.listdir(file_path_a)
    dir_list_b = os.listdir(file_path_b)
    result_dict = {
        'layer_0': [],
        'layer_1': [],
        'layer_2': [],
        'layer_3': [],
        'layer_4': [],
        'layer_5': [],
        'layer_6': [],
        'layer_7': [],
        'layer_8': [],
        'layer_9': [],
        'layer_10': [],
        'layer_11': [],
        'layer_embedding': [],
    }

    for file_a in dir_list_a:
        if file_a not in dir_list_b:
            print('{} not in {}'.format(file_a, file_path_b))
            continue
        elif '.npy' not in file_a:
            continue
        else:
            feature_a = np.load(os.path.join(file_path_a, file_a))
            feature_a_dim = feature_a.ndim
            feature_b = np.load(os.path.join(file_path_b, file_a))
            feature_b_dim = feature_b.ndim
            assert feature_a_dim == feature_b_dim
            if 'encoder.layer.0' in file_a:
                if feature_a_dim == 1:
                    cos_sim = cosine_distance(feature_a, feature_b)
                else:
                    cos_sim = np.mean(pairwise_distances(feature_a, feature_b))
                result_dict['layer_0'].append(cos_sim)
            elif 'encoder.layer.10' in file_a:
                if feature_a_dim == 1:
                    cos_sim = cosine_distance(feature_a, feature_b)
                else:
                    cos_sim = np.mean(pairwise_distances(feature_a, feature_b))
                result_dict['layer_10'].append(cos_sim)
            elif 'encoder.layer.11' in file_a:
                if feature_a_dim == 1:
                    cos_sim = cosine_distance(feature_a, feature_b)
                else:
                    cos_sim = np.mean(pairwise_distances(feature_a, feature_b))
                result_dict['layer_11'].append(cos_sim)
            elif 'encoder.layer.1' in file_a:
                if feature_a_dim == 1:
                    cos_sim = cosine_distance(feature_a, feature_b)
                else:
                    cos_sim = np.mean(pairwise_distances(feature_a, feature_b))
                result_dict['layer_1'].append(cos_sim)
            elif 'encoder.layer.2' in file_a:
                if feature_a_dim == 1:
                    cos_sim = cosine_distance(feature_a, feature_b)
                else:
                    cos_sim = np.mean(pairwise_distances(feature_a, feature_b))
                result_dict['layer_2'].append(cos_sim)
            elif 'encoder.layer.3' in file_a:
                if feature_a_dim == 1:
                    cos_sim = cosine_distance(feature_a, feature_b)
                else:
                    cos_sim = np.mean(pairwise_distances(feature_a, feature_b))
                result_dict['layer_3'].append(cos_sim)
            elif 'encoder.layer.4' in file_a:
                if feature_a_dim == 1:
                    cos_sim = cosine_distance(feature_a, feature_b)
                else:
                    cos_sim = np.mean(pairwise_distances(feature_a, feature_b))
                result_dict['layer_4'].append(cos_sim)
            elif 'encoder.layer.5' in file_a:
                if feature_a_dim == 1:
                    cos_sim = cosine_distance(feature_a, feature_b)
                else:
                    cos_sim = np.mean(pairwise_distances(feature_a, feature_b))
                result_dict['layer_5'].append(cos_sim)
            elif 'encoder.layer.6' in file_a:
                if feature_a_dim == 1:
                    cos_sim = cosine_distance(feature_a, feature_b)
                else:
                    cos_sim = np.mean(pairwise_distances(feature_a, feature_b))
                result_dict['layer_6'].append(cos_sim)
            elif 'encoder.layer.7' in file_a:
                if feature_a_dim == 1:
                    cos_sim = cosine_distance(feature_a, feature_b)
                else:
                    cos_sim = np.mean(pairwise_distances(feature_a, feature_b))
                result_dict['layer_7'].append(cos_sim)
            elif 'encoder.layer.8' in file_a:
                if feature_a_dim == 1:
                    cos_sim = cosine_distance(feature_a, feature_b)
                else:
                    cos_sim = np.mean(pairwise_distances(feature_a, feature_b))
                result_dict['layer_8'].append(cos_sim)
            elif 'encoder.layer.9' in file_a:
                if feature_a_dim == 1:
                    cos_sim = cosine_distance(feature_a, feature_b)
                else:
                    cos_sim = np.mean(pairwise_distances(feature_a, feature_b))
                result_dict['layer_9'].append(cos_sim)
            elif 'embeddings' in file_a:
                if feature_a_dim == 1:
                    cos_sim = cosine_distance(feature_a, feature_b)
                else:
                    cos_sim = np.mean(pairwise_distances(feature_a, feature_b))
                result_dict['layer_embedding'].append(cos_sim)
            else:
                continue
    assert len(result_dict['layer_0']) == len(result_dict['layer_1']) == len(result_dict['layer_2']) == \
           len(result_dict['layer_3']) == len(result_dict['layer_4']) == len(result_dict['layer_5']) == \
           len(result_dict['layer_6']) == len(result_dict['layer_7']) == len(result_dict['layer_8']) == \
           len(result_dict['layer_9']) == len(result_dict['layer_10']) == len(result_dict['layer_11'])

    final_result_dict = {}
    for key, value in result_dict.items():
        temp = []
        for x in value:
            if x < 0.01 or math.isnan(x):
                continue
            else:
                temp.append(x)
        final_result_dict[key] = np.mean(temp)

    final_result = 0
    for key, value in final_result_dict.items():
        final_result += value
    final_result = final_result / len(final_result_dict)
    return result_dict, final_result_dict, final_result


if __name__ == '__main__':
    # BC2GM + BC2GM_bCLS
    result_dict1, final_result_dict1, final_result1 = compute_layer_wise_similarity\
        ('task_embedding/BC2GM-IOB', 'task_embedding/BC2GM-bCLS')
    print(final_result1)
    # BC2GM + BC2GM_mCLS
    result_dict2, final_result_dict2, final_result2 = compute_layer_wise_similarity\
        ('task_embedding/BC2GM-IOB', 'task_embedding/BC2GM-mCLS')
    print(final_result2)
    # BC2GM + BC2GM_mtCLS
    result_dict3, final_result_dict3, final_result3 = compute_layer_wise_similarity\
        ('task_embedding/BC2GM-IOB', 'task_embedding/BC2GM-mtCLS')
    print(final_result3)
    # BC2GM_bCLS + BC2GM_mCLS
    result_dict4, final_result_dict4, final_result4 = compute_layer_wise_similarity\
        ('task_embedding/BC2GM-bCLS', 'task_embedding/BC2GM-mCLS')
    print(final_result4)
    # BC2GM_bCLS + BC2GM_mtCLS
    result_dict5, final_result_dict5, final_result5 = compute_layer_wise_similarity\
        ('task_embedding/BC2GM-bCLS', 'task_embedding/BC2GM-mtCLS')
    print(final_result5)
    # BC2GM_mCLS + BC2GM_mtCLS
    result_dict6, final_result_dict6, final_result6 = compute_layer_wise_similarity\
        ('task_embedding/BC2GM-mCLS', 'task_embedding/BC2GM-mtCLS')
    print(final_result6)

    # BC5CDR + BC5CDR_bCLS
    result_dict7, final_result_dict7, final_result7 = compute_layer_wise_similarity\
        ('task_embedding/BC2GM-IOB', 'task_embedding/BC2GM-bCLS')
    print(final_result7)
    # BC5CDR + BC5CDR_mCLS
    result_dict8, final_result_dict8, final_result8 = compute_layer_wise_similarity\
        ('task_embedding/BC2GM-IOB', 'task_embedding/BC2GM-mCLS')
    print(final_result8)
    # BC5CDR + BC5CDR_mtCLS
    result_dict9, final_result_dict9, final_result9 = compute_layer_wise_similarity\
        ('task_embedding/BC2GM-IOB', 'task_embedding/BC2GM-mtCLS')
    print(final_result9)
    # BC5CDR_bCLS + BC5CDR_mCLS
    result_dict10, final_result_dict10, final_result10 = compute_layer_wise_similarity\
        ('task_embedding/BC2GM-bCLS', 'task_embedding/BC2GM-mCLS')
    print(final_result10)
    # BC5CDR_bCLS + BC5CDR_mtCLS
    result_dict11, final_result_dict11, final_result11 = compute_layer_wise_similarity\
        ('task_embedding/BC2GM-bCLS', 'task_embedding/BC2GM-mtCLS')
    print(final_result11)
    # BC5CDR_mCLS + BC5CDR_mtCLS
    result_dict12, final_result_dict12, final_result12 = compute_layer_wise_similarity\
        ('task_embedding/BC2GM-mCLS', 'task_embedding/BC2GM-mtCLS')
    print(final_result12)

    # NCBI + NCBI_bCLS
    result_dict13, final_result_dict13, final_result13 = compute_layer_wise_similarity\
        ('task_embedding/BC2GM-IOB', 'task_embedding/BC2GM-bCLS')
    print(final_result13)
    # NCBI + NCBI_mCLS
    result_dict14, final_result_dict14, final_result14 = compute_layer_wise_similarity\
        ('task_embedding/BC2GM-IOB', 'task_embedding/BC2GM-mCLS')
    print(final_result14)
    # NCBI + NCBI_mtCLS
    result_dict15, final_result_dict15, final_result15 = compute_layer_wise_similarity\
        ('task_embedding/BC2GM-IOB', 'task_embedding/BC2GM-mtCLS')
    print(final_result15)
    # NCBI_bCLS + NCBI_mCLS
    result_dict16, final_result_dict16, final_result16 = compute_layer_wise_similarity\
        ('task_embedding/BC2GM-bCLS', 'task_embedding/BC2GM-mCLS')
    print(final_result16)
    # NCBI_bCLS + NCBI_mtCLS
    result_dict17, final_result_dict17, final_result17 = compute_layer_wise_similarity\
        ('task_embedding/BC2GM-bCLS', 'task_embedding/BC2GM-mtCLS')
    print(final_result17)
    # NCBI_mCLS + NCBI_mtCLS
    result_dict18, final_result_dict18, final_result18 = compute_layer_wise_similarity\
        ('task_embedding/BC2GM-mCLS', 'task_embedding/BC2GM-mtCLS')
    print(final_result18)
